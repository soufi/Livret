-- phpMyAdmin SQL Dump
-- version 3.5.7
-- http://www.phpmyadmin.net
--
-- Client: localhost
-- Généré le: Jeu 25 Avril 2013 à 18:22
-- Version du serveur: 5.5.29
-- Version de PHP: 5.4.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `livret`
--

-- --------------------------------------------------------

--
-- Structure de la table `livret_compo`
--

CREATE TABLE `livret_compo` (
  `_ID_COMPO_` int(4) NOT NULL AUTO_INCREMENT,
  `_LIBELLE_COMPO_` varchar(30) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`_ID_COMPO_`),
  UNIQUE KEY `_LIBELLE_COMPO_` (`_LIBELLE_COMPO_`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Contenu de la table `livret_compo`
--

INSERT INTO `livret_compo` (`_ID_COMPO_`, `_LIBELLE_COMPO_`) VALUES
(1, 'Info');

-- --------------------------------------------------------

--
-- Structure de la table `livret_enseignant`
--

CREATE TABLE `livret_enseignant` (
  `_ID_ENS_` int(4) NOT NULL AUTO_INCREMENT,
  `_NOM_ENS_` varchar(100) NOT NULL COMMENT 'Nom de l''enseignant',
  `_PRENOM_ENS_` varchar(100) NOT NULL COMMENT 'Prénom de l''enseignant',
  `_EMAIL_ENS_` varchar(150) NOT NULL COMMENT 'adresse mail enseignant',
  PRIMARY KEY (`_ID_ENS_`),
  UNIQUE KEY `_EMAIL_ENS_` (`_EMAIL_ENS_`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=26 ;

--
-- Contenu de la table `livret_enseignant`
--

INSERT INTO `livret_enseignant` (`_ID_ENS_`, `_NOM_ENS_`, `_PRENOM_ENS_`, `_EMAIL_ENS_`) VALUES
(1, 'Prénom', 'NOM', 'Prenom.NOM@univ-orleans.fr'),
(3, 'Un', 'professionnel du BRGM', 'Bureau de Recherches Géologiques et Minières'),
(4, 'Frédéric', 'MOAL', 'Frederic.MOAL@univ-orleans.fr'),
(5, 'Matthieu', 'EXBRAYAT', 'Matthieu.EXBRAYAT@univ-orleans.fr'),
(7, 'Frédéric', 'DABROWSKI', 'Frederic.DABROWSKI@univ-orleans.fr'),
(9, 'Chaker', 'HAOUET', 'Chaker.HAOUET@univ-orleans.fr'),
(10, 'Bich', 'DAO', 'Bich.DAO@univ-orleans.fr'),
(12, 'Christel', 'VRAIN', 'Christel.VRAIN@univ-orleans.fr'),
(18, 'Sébastien', 'LIMET', 'Sebastien.LIMET@univ-orleans.fr'),
(23, 'Cédric', 'SARRE', 'Cedric.SARRE@univ-orleans.fr'),
(25, 'Alfred', 'HITCHCOCK', 'alfred.hitchcock@univ-orleans.fr');

-- --------------------------------------------------------

--
-- Structure de la table `livret_filiere`
--

CREATE TABLE `livret_filiere` (
  `_ID_FILIERE_` int(4) NOT NULL AUTO_INCREMENT,
  `_LIBELLE_FILIERE_` varchar(30) CHARACTER SET utf8 NOT NULL,
  `_ID_COMPO_` int(4) NOT NULL,
  PRIMARY KEY (`_ID_FILIERE_`),
  KEY `_ID_COMPO_` (`_ID_COMPO_`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Contenu de la table `livret_filiere`
--

INSERT INTO `livret_filiere` (`_ID_FILIERE_`, `_LIBELLE_FILIERE_`, `_ID_COMPO_`) VALUES
(2, 'm2', 1);

-- --------------------------------------------------------

--
-- Structure de la table `livret_matiere`
--

CREATE TABLE `livret_matiere` (
  `_ID_MAT_` int(4) NOT NULL AUTO_INCREMENT,
  `_ID_PROMO_` int(4) NOT NULL DEFAULT '0',
  `_LIBELLE_MAT_` varchar(50) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `_CODE_APOG_MAT_` varchar(20) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `_ID_UE_` int(4) NOT NULL,
  PRIMARY KEY (`_ID_MAT_`),
  KEY `_ID_UE_` (`_ID_UE_`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

--
-- Contenu de la table `livret_matiere`
--

INSERT INTO `livret_matiere` (`_ID_MAT_`, `_ID_PROMO_`, `_LIBELLE_MAT_`, `_CODE_APOG_MAT_`, `_ID_UE_`) VALUES
(1, 7, 'Sécurité des applications nomades', 'UE 31', 1),
(2, 7, 'Système d''informations géographiques nomades', 'UE 32', 1),
(3, 7, 'Architecture applicatives réparties', 'UE 33', 1),
(4, 7, 'Projet 1', 'UE 37', 1),
(5, 7, 'Initiation à la recherche', 'UE 38', 1),
(6, 7, 'Simulation et stratégie d''entreprise', 'UE 39', 1),
(7, 7, 'Pratique des contraintes', 'UE 34 : WIN', 1),
(8, 7, 'Webmining et réseaux sociaux', 'UE35 : WIN', 1),
(9, 7, 'Extraction de connaissances dans les BD', 'UE 36 : WIN', 1),
(10, 7, 'Sécurité des communications', 'UE 34 : SSL', 1),
(11, 7, 'Sécurité des systèmes d''exploitation', 'UE 35 : SSL', 1),
(12, 7, 'Qualité et certification', 'UE 36 : SSL', 1),
(13, 7, 'Développement avancé d''applications nomades', 'UE 41', 1),
(14, 7, 'Web services et interopérabilité', 'UE 42', 1),
(15, 7, 'Visualisation avancée de données', 'UE 43 : WIN', 1),
(16, 7, 'Fouille de données et de textes', 'UE 44 : WIN', 1),
(17, 7, 'Réseaux, sécurité et nomadisme', 'UE 43 : SSL', 1),
(18, 7, 'Analyse statique', 'UE 44 : SSL', 1),
(19, 7, 'Projet 2', 'UE 45', 1),
(20, 7, 'Anglais', 'UE 47', 1),
(21, 7, 'Stage', 'UE 48', 1),
(22, 7, 'Préparation au stage recherche', 'UE 46', 1);

-- --------------------------------------------------------

--
-- Structure de la table `livret_module`
--

CREATE TABLE `livret_module` (
  `_ID_MAT_` int(4) NOT NULL DEFAULT '0',
  `_NBH_C_` int(11) NOT NULL DEFAULT '0',
  `_NBH_TD_` int(11) DEFAULT NULL,
  `_NBH_TP_` int(11) DEFAULT NULL,
  `_NBH_CTD_` int(11) DEFAULT NULL,
  `_NB_ECTS_` int(11) NOT NULL DEFAULT '0',
  `_COEF_` int(11) DEFAULT NULL,
  `_LANGUE_` varchar(20) NOT NULL DEFAULT 'Francais' COMMENT 'langue d''enseignement',
  `_OBJECTIF_` text COMMENT 'objectifs competences visees',
  `_DESCRIPTION_` text COMMENT 'Description Longue/détaillée',
  `_METHODE_EVAL_` varchar(256) DEFAULT NULL COMMENT 'mÃ©thode d''evaluation',
  `_MOD_CC_1_` varchar(256) DEFAULT NULL COMMENT 'modalitÃ© CC session 1',
  `_MOD_CC_2_` varchar(256) DEFAULT NULL COMMENT 'ModalitÃ© CC session 2',
  `_CALCUL_NF_1_` varchar(256) DEFAULT NULL COMMENT 'calcule de la note final session 1',
  `_CALCUL_NF_2_` varchar(256) DEFAULT NULL COMMENT 'calcule de la note final session 2',
  `_PREREQUIS_` text COMMENT 'pré-requis sous forme textuelle(si le pré-requis n''existe pas dans la base)',
  `_LIEN_RESSOURCE_` text,
  `_BIBLIOGRAPHIE_` text,
  `_NOTE_ELIM_` int(11) DEFAULT NULL COMMENT 'note éliminatoire (null si aucune)',
  `_OBLIGATOIRE_` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`_ID_MAT_`,`_NB_ECTS_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `livret_module`
--

INSERT INTO `livret_module` (`_ID_MAT_`, `_NBH_C_`, `_NBH_TD_`, `_NBH_TP_`, `_NBH_CTD_`, `_NB_ECTS_`, `_COEF_`, `_LANGUE_`, `_OBJECTIF_`, `_DESCRIPTION_`, `_METHODE_EVAL_`, `_MOD_CC_1_`, `_MOD_CC_2_`, `_CALCUL_NF_1_`, `_CALCUL_NF_2_`, `_PREREQUIS_`, `_LIEN_RESSOURCE_`, `_BIBLIOGRAPHIE_`, `_NOTE_ELIM_`, `_OBLIGATOIRE_`) VALUES
(1, 20, 15, 0, 0, 4, 4, 'Français_', '\n	- Capacité à configurer correctement une machine virtuelle Java en fonction d''une politique de sécurité donnée.\n	- Maîtrise des subtilités du langage Java ayant un impact sur la sécurité des applications.\n	- Connaissance des propriétés de sureté du code assurées par les machines virtuelle Java et des techniques d''analyse sous-jacentes.\n	- Application de ces techniques à des propriétés de sécurité spécifiques.\n', '\nCe cours porte sur la sécurité des applications J2ME (Java 2 Mobile Edition) et se décompose en deux parties.\nLa première partie traite des problèmes liés à la configuration de la politique de sécurité de la machine virtuelle\n(security manager, chargeur de classe, contrôle  d''accès, signature de classes, ...) et des bonnes pratiques de programmation.\nPlusieurs aspects du langage Java (héritage, modificateurs,   sérialisation, JNI...) pouvant avoir un impact sur la sécurité des  applications seront étudiés.\nEn particulier, l''accent sera mis, au travers d''une étude de la spécification du langage, sur les pratiques de développement Java conduisant à la production d''un code robuste.\nLa seconde partie du cours portera sur le code exécuté par la machine virtuelle et la spécification de cette dernière.\nEn particulier, les mécanismes de vérification de bytecode mis en oeuvre par la machine virtuelle (principalement basés sur la sureté du typage)\net les techniques d''analyse sous-jacentes seront étudiés. Finalement, ces techniques d''analyse seront généralisées afin de permettre\nleur application à des propriétés de sécurité plus précises.\n', 'Contrôle continue et terminal', 'CC et CT', 'CT', '$frac{(CC+2*CT)}{3}$', 'CT', NULL, 'Ressources', 'Biblio', 7, 0),
(2, 20, 15, 0, 0, 4, 4, 'Français_', '\n	- Développer des applications nomades basées sur la géo-localisation et utilisant des SIG.\n', '\n	- Apprentissage des principaux systèmes de géo-localisation utilisés dans l''informatique nomade. Etude des principes et des outils des systèmes d''informations géographiques (SIG).\n	- Analyse des architectures matérielles  et logicielles des SIG nomades.\n', 'Contrôle continue et terminal', 'CC et CT', 'CT', '$frac{(CC+2*CT)}{3}$', 'CT', NULL, 'Ressources', 'Biblio', 7, 0),
(3, 20, 20, 10, 0, 4, 4, 'Français_', '\n	- Fournir les outils nécessaires à l''analyse, la mise en place et l''exploitation de systèmes d''informations répartis.\n	- Apporter une solide formation sur la répartition des données et des traitements dans un Système d''Information (SI), suivant deux axes :\n	outils avancés pour la modélisation et la gestion des SI (UML, design patterns, etc.) et SI distribués contemporains (architectures multi-tiers, plateformes applicatives).\n', '\nCe module se compose de deux parties complémentaires, portant sur les aspects théoriques et pratiques des systèmes d''information répartis:\n	- Concepts et méthodes des SI. Dans cette partie l''étudiant est sensibilisé aux pratiques modernes des systèmes d''information,\n	en vue d''une prise en charge plus efficace des phases d''analyse et de conception d''applications d''entreprise :\n		  - Typologie des SI et exemples significatifs\n		  - UML et processus de développement unifié\n		  - Patron de conception (Design Patterns)\n		  - Organisation Informatique en entreprise\n	- Concepts et mise en oeuvre des SI répartis. Cette partie est essentiellement articulée autour de la plate forme J2EE.\n	Dans un premier temps, l''étudiant se familiarise avec les outils sous-jacents :\n		  - Appel d''objets répartis via RMI\n		  - Echange de messages entre applications distantes via JMS\n		  - Persistance d''objets (utilisation de différents frameworks)\n		  - Concept de transaction répartie\nPuis il étudie et met en oeuvre des applications multi-tiers sur une plateforme J2EE :\n	  - Concept de bean métier (EJB)\n	  - Intégration des différents types d''EJB\n  De nombreuses manipulations pratiques sont réalisées, en s''appuyant sur le langage Java (RMI, EJB, Corba, ...).\n', 'Contrôle continue et terminal', 'CC et CT', 'CT', '$frac{(CC+2*CT)}{3}$', 'CT', NULL, 'Ressources', 'Biblio', 7, 0),
(4, 0, 0, 0, 0, 3, 3, 'Français_', '\n	- Mise en pratique des principes et techniques étudiés dans les unités d''enseignement.\n', '\nRéalisation d''une application en rapport avec les UE du semestre. \n', 'Contrôle continue et terminal', 'Rapport et soutenance de projet', 'CT', '$frac{(CC+2*CT)}{3}$', 'CT', NULL, 'Ressources', 'Biblio', 7, 0),
(5, 57, 0, 0, 0, 7, 7, 'Français_', '\n	- L''objectif est d''initier l''étudiant à une démarche scientifique et de le familiariser à un travail de recherche bibliographique. \n	- Les tutoriaux ont pour objectif d''appréhender quelques thématiques de recherche et d''introduire des techniques récentes ou fondamentales.\n', '\nInitiation au stage recherche :\n	- introduction d''outils pour aborder un stage de recherche en laboratoire\n	- présentation du cycle de tutoriaux, des thématiques, des possibilités de poursuites en thèse et plus largement du milieu de la recherche académique ou industrielle\n	- présentation des projets académiques proposés au semestre 4\nCycle de tutoriaux :\n	- 2 tutoriaux longs (d''une durée totale de 9h; soit 2 fois 3 séances de 1h30) seront axés sur une thématique préalablement\n	choisie et pour laquelle un renforcement est sollicité par le laboratoire.\n	- 20 tutoriaux courts (de 1h30 chacun) articulés autour de thématiques telles que la résolution par contraintes,\n	l''apprentissage, extraction de connaissances, le parallélisme, la réalité virtuelle, la sécurité et sûreté des logiciels,\n	les modèles de calculs, l''algorithmique et la théorie des graphes, ...\nCes tutoriaux se voudront à la fois introductifs et concrets, mais ils apporteront également des connaissances pointues sur des domaines maîtrisés par les intervenants. \n', 'Contrôle continue et terminal', 'Rapport et soutenance de projet', 'CT', '$frac{(CC+2*CT)}{3}$', 'CT', NULL, 'Ressources', 'Biblio', 7, 0),
(6, 0, 24, 0, 0, 3, 3, 'Français_', '\n	- Connaissance du monde de l''entreprise.\n', '\nLes étudiants sont mis en situation de gérer une entreprise à travaers des décisions d''ordre commercial, financier et de production. Ces entreprises sont en concurrence sur le marché, et sont en mesure d''évaluer régulièrement leurs résultats à l''aide des documents financiers et d''études de positionnement. Ainsi cette situation de gestion d''entreprise est l''occasion d''appliquer les principaux concepts en statégies et marketing, et d''élaborer des tableaux de bord afin de guider les étudiants dans leurs décisions et d''en mesurer les impacts financier. \n', 'Contrôle continue et terminal', 'CC et CT', 'CT', '$frac{(CC+2*CT)}{3}$', 'CT', NULL, 'Ressources', 'Biblio', 7, 0),
(7, 20, 15, 0, 0, 4, 4, 'Français_', '\n	- Modélisation et résolution de problèmes par approche déclarative.\n', '\nCe module s''inscrit dans une démarche déclarative et descriptive pour modéliser et résoudre des problèmes combinatoires complexes et professionellement pertinents.\nOn y montre l''application des contraintes dans un éventail de problèmes réels, en mettant l''accent sur la pratique de la modélisation et l''utilisation des outils.\nIl s''inscrit dans la continuité du module PLC de M1 qui présente le paradigme de la programmation logique et offre une introduction aux contraintes. \n', 'Contrôle continue et terminal', 'CC et CT', 'CT', '$frac{(CC+2*CT)}{3}$', 'CT', NULL, 'Ressources', 'Biblio', 7, 0),
(8, 20, 15, 0, 0, 4, 4, 'Français_', '\n	- Savoir identifier et explorer intelligemment diverses sources d''informations offertes par le web. \n	- Objectif\n', '\n	- Fouille dans les réseaux sociaux.\n	- Systèmes de recommandation.\n	- Données ouvertes.\n	- Recherche d''information.\n', 'Contrôle continue et terminal', 'CC et CT', 'CT', '$frac{(CC+2*CT)}{3}$', 'CT', NULL, 'Ressources', 'Biblio', 7, 0),
(9, 20, 20, 10, 0, 4, 4, 'Français_', '\n	- Utilisation d''outils : Weka, RapidMiner.\n	- Définir le problème d''apprentissage : modèle à acquérir, données nécessaires, techniques applicables.\n	- Appliquer des techniques d''apprentissage.\n', '\n	- Les différents types d''apprentissage et les différentes tâches \n	- Classification supervisée : arbre de décision, modèles probabilistes, machines à vecteur support, noyaux\n	- Evaluation des modèles\n	- Classification non supervisée : par partitionnement, hiérarchique, conceptuelle\n	- Recherche de règles d''association \n', 'Contrôle continue et terminal', 'CC et CT', 'CT', '$frac{(CC+2*CT)}{3}$', 'CT', NULL, 'Ressources', 'Biblio', 7, 0),
(10, 20, 20, 0, 0, 4, 4, 'Français_', '\n	- Comprendre en profondeur les mécanismes garantissant la sécurité des systèmes et réseaux en thème de\n	confidentialité, d''authentification et de disponibilité. \n	- Modéliser un protocole à partir d''une spécification textuelle et manipuler un outil de simulation et de vérification.\n', '\nCe module introduit et familiarise les étudiants avec des notions de sécurité relatives aux communications.\nAprès un survol historique de la compétition perpétuelle entre cryptographie et cryptanalyse, avec comme point clé\nla seconde guerre mondiale et le système Enigma, les standards actuels de chiffrements symétriques et asymétriques\nsont étudiés en profondeur. Les technologies actuelles permettent des communications synchrones sur des distances\nde plusieurs centaines ou milliers de kilomètres. De plus ces communications peuvent contenir des informations\nconfidentielles et peuvent également nécessiter une authentification des personnes en communication\n(communication entre un tiers et un centre de paiement par exemple). Des protocoles de sécurité sont développés\nafin de garantir les propriétés mentionnées précédemment. \nCe module présente les mécanismes d''authentification,\nde confidentialité et d''intégrité de données et ainsi que quelques protocoles comme Kerberos.\nEnfin, le dernier point traité dans ce module démontre que des algorithmes de chiffrement parfaits ne suffisent pas pour garantir\nla sécurité d''un protocole de communication. Les étudiants sont invités à manipuler un outil de simulation et de\nvérification de protocoles de sécurité afin de détecter d''éventuelles failles logiques de conception. \n', 'Contrôle continue et terminal', 'CC et CT', 'CT', '$frac{(CC+2*CT)}{3}$', 'CT', NULL, 'Ressources', 'Biblio', 7, 0),
(11, 20, 15, 0, 0, 4, 4, 'Français_', '\n	- Connaître les grands principes de fonctionnement d''un système d''exploitation.\n	- Connaître les différents mécanismes permettant de sécuriser un système d''exploitation.\n	- Acquérir la capacité à administrer un système type UNIX/Windows.\n	- Acquérir la capacité à sécuriser et maintenir la sécurité d''un système d''exploitation.\n	- Acquérir la capacité à analyser et rétablir un système compromis.\n', '\n1. 1) Concepts de base sur l''administration Unix / Windows\n	  - Boot loader et procédure de boot matériel\n	  - Les démons et le lancement de services\n	  - Les comptes utilisateurs\n	  - Le noyau : fonctionnement, modules, configuration et compilation\n	  - Les différents types de fichiers\n2. Modèles de sécurité\n	  - Contrôle d''accès MAC, RBAC, MLS, BLP\n	  - Propriétés de sécurité\n	  - Séparation de privilèges\n3. Sécurité d''un système Linux\n	  - Sécurité système : authentification, autorisation, single sign on (LDAP, Kerberos)\n	  - Débordements de tampon (buffer overflows)\n	  - Surveillance système : Logs, HIDS, Forensics \n	  - Contrôle d''accès (SELinux, GRSecurity, ...)\n	  - Chiffrement de données\n4. Sécurité des systèmes Windows NT\n	  - Principes généraux de sécurité de Windows NT\n	  - Active directory\n	  - Mécanismes de sécurité niveau système\n	  - Sécurité client/serveur de Windows NT\n	  - Nouveautés dans Windows 7\n5. Systèmes de détection d''intrusion\n	  - Principes généraux : Introduction aux IDS\n	  - Exploitation des IDS \n', 'Contrôle continue et terminal', 'CC et CT', 'CT', '$frac{(CC+2*CT)}{3}$', 'CT', NULL, 'Ressources', 'Biblio', 7, 0),
(12, 20, 15, 0, 0, 4, 4, 'Français_', '\n	- Connaître les différents référentiels qualité.\n	- Connaître les différentes techniques d''audit.\n	- Savoir mettre en oeuvre une méthode de certification.\n', '\n1. Qualité logiciel :\n	  - Présentation de la Qualité, historique, bases de la démarche, définitions, coûts, gains, processus\n	  - Présentation des normes et référentiels Qualité (ISO 9001, CMM, ISO SPICE), assurance qualité logiciel\n	  - Plan d''assurance de la qualité logicielle\n	  - Qualité produit, ISO 9126, métrologie (qualimétrie logicielle), gestion de configuration, gestion des changements\n	  - Qualité dans la relation client/fournisseur, MOA/MOE, sous-traitants, tableaux de bord\n2. Certification :\n	  - Systèmes de management du Sysème d''information\n	  - ISO 27000, 2700x et méthode d''audit (EBIOS, MEHARI, OCTAVE, ITIL, COBIT)\n	  - Certifications (audit et organismes)\n', 'Contrôle continue et terminal', 'CC et CT', 'CT', '$frac{(CC+2*CT)}{3}$', 'CT', NULL, 'Ressources', 'Biblio', 7, 0),
(13, 20, 15, 0, 0, 3, 3, 'Français_', '\n	- Fournir à l''étudiant les connaissances matérielles embarquées dans les téléphones "nouvelle génération".\n	- Familiariser l''étudiant à la programmation d''application de réalité augmentée. Avoir connaissance du cadre légal régissant ce type d''applications.\n', '\nCe module présente les nouvelles ressources embarquées dans les téléphones "nouvelle génération" menant à de nouveaux types d''applications\ncommunément appelées "applications de réalité augmentée". Le spectre d''applications imaginables est alors conséquents,\ncependant elles doivent respecter un cadre légal. Ainsi, ce cours rappelle également la législation régissant ce type d''applications.\n1. Présentation des ressources matérielles : Wifi, Bluetooth, capteurs, accéléromètres\n2. Description des différentes API selon le support\n3. Interactions avec des services WEB\n4. Cas d''étude : un exemple de développement d''une application "réalité augmentée"\n5. Publication des applications \n', 'Contrôle continue et terminal', 'CC et CT', 'CT', '$frac{(CC+2*CT)}{3}$', 'CT', NULL, 'Ressources', 'Biblio', 7, 0),
(14, 15, 15, 10, 0, 3, 3, 'Français_', '\n	- Comprendre l''architecture et les technologies sous-jacentes des Services Web, pour permettre l''interopérabilité entre des systèmes d''information hétérogènes.\n', '\nCe module permet de comprendre l''intérêt et les technologies sous-jacentes mises en oe uvre dans les architectures de type\nServices Web (SOAP, WSDL, HTTP, XML...). Le cours magistral présente les technologies et les outils (libres et commerciaux)\net les séances de travaux dirigés sur machines permettent de mettre en pratique les notions présentées en développant deux\nSI sous java J2EE et Microsoft .NET qui interopèrent à l''aide d''une architecture orientée service. \n', 'Contrôle continue et terminal', 'CC et CT', 'CT', '$frac{(CC+2*CT)}{3}$', 'CT', NULL, 'Ressources', 'Biblio', 7, 0),
(15, 20, 15, 0, 0, 3, 3, 'Français_', '\n	- Comprendre différentes techniques de visualisation d''information scientifique.\n	- Comprendre le fonctionnement d''une application graphique nomade.\n	- Aborder sur des exemples les principes des applications  de visualisation scientifique portants sur des données massives de type geo-scientifique ou biologie moléculaire.\n', '\nLa complexité sémantique et la massivité des données issues de mesures scientifiques, de simulations numériques ou\nd''immenses bases de données disponibles sur le réseau, rendent indispensable le recours à la médiation visuelle pour\nen permettre une appréhension la plus riche possible.  La mise en oeuvre de  techniques de visualisation élaborées\nconduit à utiliser des architectures parallèles et distribués pour faire face à la complexité des traitements numériques\nen amont ou propre au rendu visuel. Cette puissance de traitement peut être mise en oeuvre pour simplifier le rendu\nafin de l''adapter à un rendu nomade, mais elle  peut aussi adapter les données en post-traitement pour que celles-ci\nsoient analysées via un vaste environnement de Réalité Virtuelle multi-écrans plus ou moins distant sur le réseau.\nNous présentons dans ce cours  les fondements du pipeline graphique parallèle, les différentes techniques de rendu\nscientifique, les moyens d''adapter le rendu nomade aux gros volumes de données complexes et enfin nous abordons\nla visualisation scientifique utilisant les techniques avancées de Réalité Virtuelle au service de la performance.\n', 'Contrôle continue et terminal', 'CC et CT', 'CT', '$frac{(CC+2*CT)}{3}$', 'CT', NULL, 'Ressources', 'Biblio', 7, 0),
(16, 15, 15, 10, 0, 3, 3, 'Français_', '\n	- Compléter les connaissances acquises en fouille de données et acquérir de nouvelles compétences sur la fouile de données textuelles. \n	- Les données textes ont pris une importance croissante avec le développement d''Internet qui permet de récupérer rapidement des masses de documents.\n	- Il est important d''avoir des outils permettant de traiter les documents, que ce soit pour la classification,\n	la recherche d''informations, la structuration de connaissances sur un domaine, le web sémantique, ...\n', '\nCet enseignement permet d''une part, d''introduire des techniques importantes, principalement statistiques et bayésiennes,\nnon présentées dans le module Extraction de Connaissances dans les BD, d''autre part, d''élargir la problématique à des\ntypes de données complexes comme les données textuelles.\n1. Algorithme de fouille de données (approfondissement)\n	  - apprentissage statistique (réseaux de neurones, machines à vecteur support, ...)\n	  - apprentissage bayésien\n2. Extraction de Connaissances à partir de textes \n	  - Préparation des données\n	  - Documents structurés (XML, ...)\n	  - Classification de documents \n', 'Contrôle continue et terminal', 'CC et CT', 'CT', '$frac{(CC+2*CT)}{3}$', 'CT', NULL, 'Ressources', 'Biblio', 7, 0),
(17, 20, 15, 0, 0, 3, 3, 'Français_', '\n	- Découvrir les différents types de réseaux sans fils (IP, GSM, ...).\n	- Connaître les spécificités des réseaux IP sans fils.\n	- Connaître les protocoles de sécurité classiques.\n	- Être capable de sécuriser une architecture réseau pour des applications nomades.\n', '\nProtocoles et sécurité:\\\nLes attaques réseau. Les méthodes de protection (inetd, tcpwrappers, arp).\nProtection des accès distants (PKI, SSO). Switch. VLAN. Routeurs.\nPare-feux, pare-feux applicatifs, proxy.\nIPSec, VPN.\nSSL, TLS, SSH.\nNIDS.\nMobilité dans les réseaux sans fil de type 802.xx:\\\nRéseaux mobiles et protocoles IP (IPV6, HMIP, LERS, SIP).\nRéseaux mobiles adhoc (par exemple MANET).\nRéseaux mobiles de type NEMO (Network Mobility).\nMobilité dans les réseaux téléphoniques:\\\nGénérations de mobiles (GSM, GPRS, 3G, 3G+, UMTS).\nSécurité des réseaux sans fils:\\\nSécurité des réseaux GSM (authentification et chiffrement, sécurité des cartes SIM, interception d''appel, sécurité des services de DATA (SMS, MMS)).\nIntégrité, confidentialité et disponibilité des données sur les réseaux sans fil (filtrage des adresses MAC, WEP/WPA/WPA2, AAA : Radius, Portail Captif, VPN). \n', 'Contrôle continue et terminal', 'CC et CT', 'CT', '$frac{(CC+2*CT)}{3}$', 'CT', NULL, 'Ressources', 'Biblio', 7, 0),
(18, 20, 15, 0, 0, 3, 3, 'Français_', '\n	- Connaissances des fondements de l''analyse statique de programmes.\n	- Capacité à utiliser ces connaissances pour le développement d''outils de sûreté et de sécurité.\n', '\nLa vérification de propriétés dynamiques des programmes, comme par exemple l''absence d''accès à des pointeurs nuls, est un problème généralement indécidable.\nL''interprétation abstraite dont traite ce cours fournit un cadre formel et des outils permettant de déterminer des approximations décidables\nde ces propriétés pour lesquelles il est possible de dériver des systèmes de type, de vérification et d''analyse statique.\nCe cours introduit les connaissances nécessaires à la mise oeuvre des techniques d''interprétation abstraite (théorie des ordres,\nthéorie des points fixes, connexions de Galois,...). Des exemples concrets d''utilisation de ces techniques seront étudiés et des outils\nd''analyse statique existants (Frama-C, Astree) seront présentés. \n', 'Contrôle continue et terminal', 'CC et CT', 'CT', '$frac{(CC+2*CT)}{3}$', 'CT', NULL, 'Ressources', 'Biblio', 7, 0),
(19, 0, 0, 0, 0, 3, 3, 'Français_', '\n	- Mise en pratique de principes et de techniques étudiés dans les unités d''enseignement. \n', '\nRéalisation d''une application en rapport avec les UE du semestre. \n', 'Contrôle continue et terminal', 'Rapport et soutenance de projet', 'CT', '$frac{(CC+2*CT)}{3}$', 'CT', NULL, 'Ressources', 'Biblio', 7, 0),
(20, 0, 24, 0, 0, 3, 3, 'Français_', '\n	- Savoir négocier des contrats.\n', '\nÉtude des technique de présentation orale : amélioration de la prononciation, organisation du discours, guidage de l''auditoire, élaboration d''aides visuelles. \n', 'Contrôle continue et terminal', 'CC et CT', 'CT', '$frac{(CC+2*CT)}{3}$', 'CT', NULL, 'Ressources', 'Biblio', 7, 0),
(21, 0, 0, 0, 0, 12, 12, 'Français_', '\n	- Appliquer tous les concepts vu durant le master.\n', '\n	- Un stage en entreprise à temps complet de 4 à 6 mois ou\n	- Un stage de recherche  à  temps complet de 4 à 6 mois dans un laboratoire au sein d''une équipe de\n	recherche confronte l''étudiant au monde de la recherche et lui permet à  la fois d''approfondir et d''individualiser\n	la formation de base. Bien qu''il soit conseillé de faire le stage en laboratoire de recherche, le stage peut se dérouler\n	dans un service de recherche et développement d''une entreprise.\nLa recherche du stage est à l''initiative de l''étudiant.\nCependant, le sujet doit être validé par les responsables de la formation. Le stage fait l''objet d''une convention\nengageant l''entreprise ou le laboratoire, l''université et l''étudiant.  \n', 'Contrôle continue et terminal', 'CC et CT', 'CT', '$frac{(CC+2*CT)}{3}$', 'CT', NULL, 'Ressources', 'Biblio', 7, 0),
(22, 0, 0, 0, 0, 6, 6, 'Français_', '\n	- Savoir réaliser un état de l''art dans un domaine spécialisé de la recherche en informatique et être à même d''amorcer une démarche scientifique.\n', '\n	- Réalisation d''un état de l''art ou/et d''une expérimentation dans un domaine précis de l''informatique.\n	- Initiation à la recherche.\nLes étudiants assistent à 4h de cours pour avoir les prérequis pour ce module.\n', 'Contrôle continue et terminal', 'Rapport et soutenance de projet', 'CT', '$frac{(CC+2*CT)}{3}$', 'CT', NULL, 'Ressources', 'Biblio', 7, 0);

-- --------------------------------------------------------

--
-- Structure de la table `livret_parcours`
--

CREATE TABLE `livret_parcours` (
  `_ID_FILIERE_` int(4) NOT NULL,
  `_ID_PROMO_` int(4) NOT NULL,
  PRIMARY KEY (`_ID_FILIERE_`,`_ID_PROMO_`),
  KEY `_ID_PROMO_` (`_ID_PROMO_`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `livret_parcours`
--

INSERT INTO `livret_parcours` (`_ID_FILIERE_`, `_ID_PROMO_`) VALUES
(2, 7);

-- --------------------------------------------------------

--
-- Structure de la table `livret_pre_requis`
--

CREATE TABLE `livret_pre_requis` (
  `_ID_MOD_FILS_` int(4) NOT NULL COMMENT 'module requerant',
  `_ID_MOD_PERE_` int(4) NOT NULL COMMENT 'module requis',
  `_DESCRIPTION_` text NOT NULL,
  PRIMARY KEY (`_ID_MOD_FILS_`,`_ID_MOD_PERE_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `livret_pre_requis`
--

INSERT INTO `livret_pre_requis` (`_ID_MOD_FILS_`, `_ID_MOD_PERE_`, `_DESCRIPTION_`) VALUES
(1, 1, ''),
(2, 1, ''),
(3, 0, ''),
(3, 1, ''),
(4, 1, ''),
(5, 1, ''),
(6, 0, ''),
(6, 1, ''),
(7, 0, ''),
(7, 1, ''),
(8, 0, ''),
(9, 1, ''),
(10, 1, ''),
(11, 0, ''),
(11, 1, ''),
(12, 0, ''),
(12, 1, ''),
(13, 0, ''),
(13, 1, ''),
(14, 0, ''),
(14, 1, ''),
(15, 1, ''),
(16, 1, ''),
(17, 1, ''),
(18, 0, ''),
(18, 1, ''),
(19, 1, ''),
(20, 1, ''),
(21, 0, ''),
(22, 0, ''),
(23, 0, ''),
(24, 0, ''),
(25, 0, ''),
(26, 1, ''),
(27, 0, ''),
(28, 1, ''),
(29, 1, ''),
(30, 0, ''),
(31, 1, ''),
(32, 1, ''),
(33, 1, ''),
(34, 0, ''),
(35, 0, ''),
(36, 1, ''),
(37, 1, ''),
(38, 1, ''),
(39, 1, ''),
(40, 1, ''),
(41, 1, ''),
(42, 0, ''),
(43, 1, ''),
(44, 1, ''),
(45, 1, ''),
(46, 1, ''),
(47, 1, ''),
(48, 0, ''),
(49, 1, ''),
(50, 1, ''),
(51, 1, ''),
(52, 1, ''),
(53, 1, ''),
(54, 1, ''),
(55, 0, ''),
(56, 0, ''),
(57, 1, ''),
(58, 0, ''),
(59, 0, ''),
(60, 1, ''),
(61, 1, ''),
(62, 1, ''),
(63, 0, ''),
(64, 1, ''),
(65, 1, ''),
(66, 0, ''),
(67, 1, ''),
(68, 1, ''),
(69, 1, ''),
(70, 1, ''),
(71, 1, ''),
(72, 1, ''),
(73, 1, ''),
(74, 1, ''),
(75, 0, ''),
(76, 0, ''),
(77, 1, ''),
(78, 0, ''),
(79, 0, ''),
(80, 1, ''),
(81, 1, ''),
(82, 1, ''),
(83, 1, ''),
(84, 1, ''),
(85, 0, ''),
(86, 0, ''),
(87, 1, ''),
(88, 0, ''),
(89, 0, ''),
(90, 1, ''),
(91, 1, ''),
(92, 1, ''),
(93, 0, ''),
(94, 1, ''),
(95, 1, ''),
(96, 0, ''),
(97, 1, ''),
(98, 1, ''),
(99, 1, ''),
(100, 1, ''),
(101, 1, ''),
(102, 1, ''),
(103, 1, ''),
(104, 1, ''),
(105, 1, ''),
(106, 1, ''),
(107, 1, ''),
(108, 1, ''),
(109, 1, ''),
(110, 0, ''),
(111, 1, ''),
(112, 1, ''),
(113, 1, ''),
(114, 0, ''),
(115, 1, ''),
(116, 0, ''),
(117, 0, ''),
(118, 0, ''),
(119, 1, ''),
(120, 0, ''),
(121, 0, ''),
(122, 1, ''),
(123, 0, ''),
(124, 0, ''),
(125, 0, ''),
(126, 0, ''),
(127, 0, ''),
(128, 0, ''),
(129, 0, ''),
(130, 0, ''),
(131, 0, ''),
(132, 0, ''),
(133, 0, ''),
(134, 0, ''),
(135, 0, ''),
(136, 0, ''),
(137, 0, ''),
(138, 0, ''),
(139, 0, ''),
(140, 0, ''),
(141, 0, ''),
(142, 0, ''),
(143, 0, ''),
(144, 0, ''),
(145, 1, ''),
(146, 0, ''),
(147, 0, ''),
(148, 0, ''),
(149, 0, ''),
(150, 1, ''),
(151, 0, ''),
(152, 1, ''),
(153, 0, ''),
(154, 1, ''),
(155, 1, ''),
(156, 1, ''),
(157, 1, ''),
(158, 1, ''),
(159, 0, ''),
(160, 0, ''),
(161, 0, ''),
(162, 1, ''),
(163, 1, ''),
(164, 1, ''),
(165, 0, ''),
(166, 0, ''),
(167, 1, ''),
(168, 1, ''),
(169, 1, ''),
(170, 1, ''),
(171, 1, ''),
(172, 1, ''),
(173, 1, ''),
(174, 1, ''),
(175, 0, ''),
(176, 0, ''),
(177, 1, ''),
(178, 0, ''),
(179, 0, ''),
(180, 1, ''),
(181, 1, ''),
(182, 1, ''),
(183, 0, ''),
(184, 1, ''),
(185, 1, ''),
(186, 1, ''),
(187, 1, ''),
(188, 0, ''),
(189, 1, ''),
(190, 1, ''),
(191, 0, ''),
(192, 1, ''),
(193, 0, ''),
(194, 1, ''),
(195, 1, ''),
(196, 0, ''),
(197, 0, ''),
(198, 1, ''),
(199, 0, ''),
(200, 1, ''),
(201, 1, ''),
(202, 1, ''),
(203, 1, ''),
(204, 1, ''),
(205, 1, ''),
(206, 0, ''),
(207, 0, ''),
(208, 0, ''),
(209, 0, ''),
(210, 0, ''),
(211, 0, ''),
(212, 1, ''),
(213, 1, ''),
(214, 1, ''),
(215, 0, ''),
(216, 1, ''),
(217, 0, ''),
(218, 1, ''),
(219, 1, ''),
(220, 0, '');

-- --------------------------------------------------------

--
-- Structure de la table `livret_promotion`
--

CREATE TABLE `livret_promotion` (
  `_ID_PROMO_` int(4) NOT NULL AUTO_INCREMENT,
  `_LIBELLE_PROMO_` varchar(20) CHARACTER SET utf8 NOT NULL,
  `_NB_ELEVES_PROMO_` int(11) NOT NULL DEFAULT '0',
  `_INTITULE_PROMO_` varchar(50) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `_PREAMBULE_` text CHARACTER SET utf8,
  `_EPILOGUE_` text CHARACTER SET utf8,
  `_COULEUR1_` varchar(12) CHARACTER SET utf8 NOT NULL DEFAULT '0,92,133',
  `_COULEUR2_` varchar(12) CHARACTER SET utf8 NOT NULL DEFAULT '100,151,186',
  `_COULEUR3_` varchar(12) CHARACTER SET utf8 NOT NULL DEFAULT '255,255,255',
  `_CFG_` varchar(12) CHARACTER SET utf16 NOT NULL,
  `_CPG` varchar(12) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`_ID_PROMO_`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Contenu de la table `livret_promotion`
--

INSERT INTO `livret_promotion` (`_ID_PROMO_`, `_LIBELLE_PROMO_`, `_NB_ELEVES_PROMO_`, `_INTITULE_PROMO_`, `_PREAMBULE_`, `_EPILOGUE_`, `_COULEUR1_`, `_COULEUR2_`, `_COULEUR3_`, `_CFG_`, `_CPG`) VALUES
(2, 'Licence1et2', 0, '', NULL, NULL, '0,92,133', '100,151,186', '255,255,255', '', ''),
(3, 'INFO', 0, '', NULL, NULL, '0,92,133', '100,151,186', '255,255,255', '', ''),
(4, 'm1', 0, '', NULL, NULL, '0,92,133', '100,151,186', '255,255,255', '', ''),
(5, 'MIAGE', 0, '', NULL, NULL, '0,92,133', '100,151,186', '255,255,255', '', ''),
(6, 'CCI', 0, '', NULL, NULL, '0,92,133', '100,151,186', '255,255,255', '', ''),
(7, 'INIS', 0, '', NULL, NULL, '0,92,133', '100,151,186', '255,255,255', '', ''),
(8, 'MIAGE_SIMSA', 0, '', NULL, NULL, '0,92,133', '100,151,186', '255,255,255', '', ''),
(9, 'MIAGE_SIR', 0, '', NULL, NULL, '0,92,133', '100,151,186', '255,255,255', '', ''),
(10, 'VIP', 0, '', NULL, NULL, '0,92,133', '100,151,186', '255,255,255', '', ''),
(11, 'MoCaHP', 0, '', NULL, NULL, '0,92,133', '100,151,186', '255,255,255', '', ''),
(12, 'MIAGE', 0, '', NULL, NULL, '0,92,133', '100,151,186', '255,255,255', '', '');

-- --------------------------------------------------------

--
-- Structure de la table `livret_responsable_module`
--

CREATE TABLE `livret_responsable_module` (
  `_ID_MOD_` int(4) NOT NULL DEFAULT '0',
  `_ID_ENS_` int(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`_ID_MOD_`,`_ID_ENS_`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Contenu de la table `livret_responsable_module`
--

INSERT INTO `livret_responsable_module` (`_ID_MOD_`, `_ID_ENS_`) VALUES
(1, 0),
(1, 1),
(1, 2),
(1, 55),
(2, 0),
(2, 2),
(2, 55),
(3, 0),
(3, 3),
(3, 5),
(3, 58),
(4, 0),
(4, 4),
(4, 7),
(4, 60),
(5, 0),
(5, 5),
(5, 7),
(5, 60),
(6, 0),
(6, 2),
(6, 6),
(6, 55),
(7, 0),
(7, 2),
(7, 7),
(7, 55),
(8, 0),
(8, 2),
(8, 8),
(8, 55),
(9, 0),
(9, 2),
(9, 55),
(10, 0),
(10, 2),
(10, 9),
(10, 55),
(11, 0),
(11, 2),
(11, 6),
(11, 55),
(12, 0),
(12, 2),
(12, 10),
(12, 55),
(13, 0),
(13, 2),
(13, 11),
(13, 55),
(14, 0),
(14, 2),
(14, 6),
(14, 55),
(15, 0),
(15, 2),
(15, 7),
(15, 55),
(16, 0),
(16, 2),
(16, 12),
(16, 55),
(17, 0),
(17, 2),
(17, 13),
(17, 55),
(18, 0),
(18, 2),
(18, 7),
(18, 55),
(19, 0),
(19, 2),
(19, 6),
(19, 55),
(20, 0),
(20, 2),
(20, 9),
(20, 55),
(21, 0),
(21, 14),
(21, 25),
(21, 78),
(22, 0),
(22, 2),
(22, 15),
(22, 55),
(23, 16),
(24, 17),
(25, 18),
(26, 19),
(27, 20),
(28, 4),
(29, 15),
(30, 21),
(31, 4),
(32, 7),
(33, 19),
(34, 22),
(35, 4),
(36, 6),
(37, 23),
(38, 10),
(39, 24),
(40, 25),
(41, 26),
(42, 22),
(43, 27),
(44, 28),
(45, 29),
(46, 30),
(47, 26),
(48, 31),
(49, 32),
(50, 8),
(51, 2),
(52, 10),
(53, 33),
(54, 33),
(55, 34),
(56, 35),
(57, 36),
(58, 22),
(59, 6),
(60, 20),
(61, 23),
(62, 4),
(63, 33),
(64, 36),
(65, 23),
(65, 33),
(66, 27),
(67, 37),
(68, 38),
(69, 24),
(70, 38),
(71, 37),
(72, 20),
(73, 39),
(74, 40),
(75, 10),
(76, 41),
(77, 20),
(78, 10),
(79, 38),
(80, 8),
(81, 2),
(82, 10),
(83, 33),
(84, 33),
(85, 34),
(86, 35),
(87, 36),
(88, 22),
(89, 6),
(90, 20),
(91, 23),
(92, 4),
(93, 33),
(94, 36),
(95, 23),
(95, 33),
(96, 27),
(97, 10),
(98, 37),
(99, 42),
(100, 6),
(101, 24),
(102, 28),
(102, 33),
(103, 40),
(104, 32),
(105, 10),
(106, 27),
(107, 28),
(108, 10),
(108, 41),
(109, 40),
(110, 11),
(111, 41),
(112, 24),
(112, 43),
(113, 7),
(114, 7),
(115, 24),
(115, 38),
(116, 7),
(117, 7),
(118, 7),
(119, 7),
(120, 7),
(121, 7),
(122, 7),
(123, 7),
(124, 7),
(125, 7),
(126, 7),
(127, 7),
(128, 7),
(129, 7),
(130, 7),
(131, 7),
(132, 7),
(133, 7),
(134, 7),
(135, 7),
(136, 7),
(137, 7),
(138, 7),
(139, 7),
(140, 7),
(141, 7),
(142, 7),
(143, 7),
(144, 7),
(145, 7),
(146, 7),
(147, 7),
(148, 7),
(149, 7),
(150, 8),
(151, 2),
(152, 10),
(153, 35),
(154, 44),
(155, 7),
(156, 31),
(157, 9),
(158, 45),
(159, 35),
(160, 8),
(161, 6),
(162, 20),
(163, 35),
(164, 35),
(165, 31),
(166, 46),
(167, 9),
(168, 35),
(169, 6),
(170, 8),
(171, 2),
(172, 10),
(173, 33),
(174, 33),
(175, 34),
(176, 35),
(177, 36),
(178, 22),
(179, 6),
(180, 20),
(181, 23),
(182, 4),
(183, 33),
(184, 36),
(185, 23),
(185, 33),
(186, 7),
(187, 47),
(188, 6),
(188, 32),
(189, 27),
(189, 32),
(190, 27),
(190, 32),
(191, 39),
(192, 37),
(193, 32),
(194, 11),
(195, 7),
(196, 7),
(197, 7),
(198, 7),
(199, 7),
(200, 48),
(201, 11),
(202, 7),
(203, 7),
(204, 7),
(205, 40),
(206, 7),
(206, 45),
(207, 7),
(208, 49),
(209, 43),
(210, 50),
(211, 39),
(212, 24),
(212, 43),
(213, 24),
(213, 43),
(214, 51),
(215, 48),
(216, 11),
(217, 52),
(218, 24),
(218, 43),
(219, 40),
(220, 24);

-- --------------------------------------------------------

--
-- Structure de la table `livret_semestre`
--

CREATE TABLE `livret_semestre` (
  `_ID_PROMO_` int(4) NOT NULL,
  `_ID_MAT_` int(4) NOT NULL,
  `_SEMESTRE_` varchar(15) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`_ID_PROMO_`,`_ID_MAT_`,`_SEMESTRE_`),
  KEY `_ID_MAT_` (`_ID_MAT_`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `livret_semestre`
--

INSERT INTO `livret_semestre` (`_ID_PROMO_`, `_ID_MAT_`, `_SEMESTRE_`) VALUES
(7, 1, 'Semestre 3'),
(7, 2, 'Semestre 3'),
(7, 3, 'Semestre 3'),
(7, 4, 'Semestre 3'),
(7, 5, 'Semestre 3'),
(7, 6, 'Semestre 3'),
(7, 7, 'Semestre 3'),
(7, 8, 'Semestre 3'),
(7, 9, 'Semestre 3'),
(7, 10, 'Semestre 3'),
(7, 11, ''),
(7, 12, 'Semestre 3'),
(7, 13, 'Semestre 4'),
(7, 14, 'Semestre 4'),
(7, 15, 'Semestre 4'),
(7, 16, 'Semestre 4'),
(7, 17, 'Semestre 4'),
(7, 18, ''),
(7, 19, 'Semestre 4'),
(7, 20, 'Semestre 4'),
(7, 21, ''),
(7, 22, 'Semestre 4');

-- --------------------------------------------------------

--
-- Structure de la table `livret_ue`
--

CREATE TABLE `livret_ue` (
  `_ID_UE_` int(4) NOT NULL AUTO_INCREMENT,
  `_LIBELLE_UE_` varchar(20) CHARACTER SET utf8 NOT NULL DEFAULT '',
  PRIMARY KEY (`_ID_UE_`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Contenu de la table `livret_ue`
--

INSERT INTO `livret_ue` (`_ID_UE_`, `_LIBELLE_UE_`) VALUES
(1, 'Informatique'),
(2, 'Maths'),
(3, 'Sciences éco-humaine'),
(4, 'Ang et Tech de co'),
(5, 'Architecture logicie');

--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `livret_filiere`
--
ALTER TABLE `livret_filiere`
  ADD CONSTRAINT `livret_filiere_ibfk_1` FOREIGN KEY (`_ID_COMPO_`) REFERENCES `livret_compo` (`_ID_COMPO_`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `livret_matiere`
--
ALTER TABLE `livret_matiere`
  ADD CONSTRAINT `livret_matiere_ibfk_1` FOREIGN KEY (`_ID_UE_`) REFERENCES `livret_ue` (`_ID_UE_`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `livret_module`
--
ALTER TABLE `livret_module`
  ADD CONSTRAINT `livret_module_ibfk_1` FOREIGN KEY (`_ID_MAT_`) REFERENCES `livret_matiere` (`_ID_MAT_`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `livret_parcours`
--
ALTER TABLE `livret_parcours`
  ADD CONSTRAINT `livret_parcours_ibfk_1` FOREIGN KEY (`_ID_FILIERE_`) REFERENCES `livret_filiere` (`_ID_FILIERE_`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `livret_parcours_ibfk_2` FOREIGN KEY (`_ID_PROMO_`) REFERENCES `livret_promotion` (`_ID_PROMO_`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `livret_semestre`
--
ALTER TABLE `livret_semestre`
  ADD CONSTRAINT `livret_semestre_ibfk_1` FOREIGN KEY (`_ID_PROMO_`) REFERENCES `livret_promotion` (`_ID_PROMO_`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `livret_semestre_ibfk_2` FOREIGN KEY (`_ID_MAT_`) REFERENCES `livret_matiere` (`_ID_MAT_`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
